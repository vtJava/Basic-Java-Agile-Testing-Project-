package ie.gmit.dip.AnnotationInterfaces;

/** @interface AfterAll
 */

public @interface AfterAll {

}
