package ie.gmit.dip.AnnotationInterfaces;

/**
 * @interface BeforeAll
 */

public @interface BeforeAll {

}
