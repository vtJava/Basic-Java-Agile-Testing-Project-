package ie.gmit.dip.AnnotationInterfaces;

/**
 * @interface ValueSource
 */

public @interface ValueSource {

	String[] strings();

}
