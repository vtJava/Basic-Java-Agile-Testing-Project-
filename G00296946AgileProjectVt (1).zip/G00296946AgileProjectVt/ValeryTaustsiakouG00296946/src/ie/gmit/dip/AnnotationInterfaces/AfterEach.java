package ie.gmit.dip.AnnotationInterfaces;

/** @interface AfterEach
 */
public @interface AfterEach {

}
