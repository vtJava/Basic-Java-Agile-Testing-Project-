package ie.gmit.dip.AnnotationInterfaces;

/**
 * @inteface ParameterizedTest
 */

public @interface ParameterizedTest {

}
