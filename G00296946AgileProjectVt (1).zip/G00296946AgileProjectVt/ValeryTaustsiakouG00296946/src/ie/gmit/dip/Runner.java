package ie.gmit.dip;

/** @versionEclipse 15.0.2
 * @versionJUnit 4
 * @author Valery Taustsiakou
 * Student Number: G00296946
 *
 */

public class Runner {
	
	/**
	 * @parameter main method
	 * @return AgeSelection Menu
	 * @throws Exception 
	 */
	
		public static void main(String[] args) throws Exception {
			AgeSelectionMenu.start();  
		}

	}
